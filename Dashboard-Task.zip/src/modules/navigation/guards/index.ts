import { NavigationGuard } from './navigation.guard';

export const guards = [NavigationGuard];

export * from './navigation.guard';
