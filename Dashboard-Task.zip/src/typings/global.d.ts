interface Dictionary<T> {
    [key: string]: T;
}

type UUID = string;